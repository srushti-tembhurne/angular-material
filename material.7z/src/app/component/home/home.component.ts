import { Component, OnInit } from '@angular/core';
import { NavComponent } from '../nav/nav.component'
import { CommonService } from '../../service/common.service';

@Component({
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  User:string;
  constructor(private CS:CommonService) { }

  ngOnInit() {
    this.User=this.CS.getUserName();
  }
  logout(){
    this.CS.onlogout();
  }

}
